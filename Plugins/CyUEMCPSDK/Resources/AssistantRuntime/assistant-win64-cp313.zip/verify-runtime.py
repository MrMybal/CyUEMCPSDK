import importlib.metadata as metadata
import json, pathlib, sys
import cytools_core, mcp, PIL, pypdf, cyue_mcp.service, pywintypes, win32api
import cyue_mcp
manifest = json.loads((pathlib.Path(__file__).parent / "runtime-manifest.json").read_text(encoding="utf-8"))
for name, version in manifest["packages"].items():
    assert metadata.version(name) == version, name
assert sys.version.split()[0] == manifest["pythonVersion"]
assert sys.flags.isolated and sys.dont_write_bytecode
print(json.dumps({"python": sys.version.split()[0], "sdk": cyue_mcp.__version__}))
